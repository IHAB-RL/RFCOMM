package de.jade_hs.tgm.ihabluetoothserialaudio;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    private BluetoothAdapter BA;
    private Set<BluetoothDevice> pairedDevices;
    public static Activity activity;
    private ConnectedThread mConnectedThread = null;
    private static final String TAG = "IhaBtAudio";
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private static final int block_size = 32;
    private static final int RECORDER_SAMPLERATE = 16000;
    private int BufferElements2Rec = block_size * 16; // want to play 2048 (2K) since 2 bytes we use only 1024
    private static final int RECORDER_CHANNELS = AudioFormat.CHANNEL_IN_STEREO;
    private static final int RECORDER_AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT;
    private AudioTrack audioTrack;
    private int AudioVolume = 0;
    private TextView LogView;
    private Button ConnectButton;
    private TextView textErrorValue;
    private TextView textViewVolume;
    private TextView textErrorRealNumbersLabel;
    private TextView textViewLeftLevel;
    private TextView textViewRightLevel;
    int numBlocks = 0;
    int lostBlocks = 0;
    int leftLevel = 0;
    int rightLevel = 0;
    boolean isRecording = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = this;
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        View Content = findViewById(R.id.Content);
        textErrorValue = (TextView)findViewById(R.id.textErrorValue);
        textViewVolume = (TextView)findViewById(R.id.textViewVolume);
        textErrorRealNumbersLabel = (TextView)findViewById(R.id.textErrorRealNumbersLabel);
        textViewLeftLevel = (TextView)findViewById(R.id.textViewLeftLevel);
        textViewRightLevel = (TextView)findViewById(R.id.textViewRightLevel);
        LogView = (TextView)findViewById(R.id.LogView);
        ConnectButton = (Button)findViewById(R.id.button_Reconnect);
        ConnectButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                connectBtDevice();
            }
        });
        Button button = (Button)findViewById(R.id.button_VolumeUp);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AudioVolume += 1;
                setVolume();
            }
        });
        button = (Button)findViewById(R.id.button_VolumeDown);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AudioVolume -= 1;
                setVolume();
            }
        });
        button = (Button)findViewById(R.id.button_Record);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                recordAudio();
            }
        });
        CheckBox checkbox = (CheckBox)findViewById(R.id.checkBox_adaptiveBitShift);
        checkbox.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setAdaptiveBitShift();
            }
        });
        initAudioTrack();
        initBluetooth();
        connectBtDevice();
        getApplicationContext().registerReceiver(mReceiver,
                new IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED));
        getApplicationContext().registerReceiver(mReceiver,
                new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED));
    }

    protected void initAudioTrack() {
        if (audioTrack == null) {
            audioTrack = new AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    RECORDER_SAMPLERATE,
                    RECORDER_CHANNELS,
                    RECORDER_AUDIO_ENCODING,
                    BufferElements2Rec,
                    AudioTrack.MODE_STREAM);
            audioTrack.play();
        }
    }

    protected void initBluetooth() {
        BA = BluetoothAdapter.getDefaultAdapter();
        if (BA != null) {
            if (!BA.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                int REQUEST_ENABLE_BT = 1;
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_select_device) {
            PopupMenu popupMenu = new PopupMenu(MainActivity.this, findViewById(R.id.toolbar));
            pairedDevices = BA.getBondedDevices();
            for(BluetoothDevice bt : pairedDevices)
                popupMenu.getMenu().add(bt.getName());
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    String deviceAddress = "";
                    for(BluetoothDevice bt : pairedDevices)
                        if (item.getTitle().equals(bt.getName().toString()))
                            deviceAddress = bt.getAddress();
                    LogView.append("Device '" + deviceAddress + "' selected\n");
                    SharedPreferences sharedPref = activity.getPreferences(Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("BtDeviceAddress", deviceAddress);
                    editor.commit();
                    connectBtDevice();
                    return true;
                }
            });
            popupMenu.show();
        }
        return super.onOptionsItemSelected(item);
    }

    private void connectBtDevice()
    {
        if (BA.isEnabled()) {
            ConnectButton.setEnabled(false);
            LogView.append("Bluetooth is active...\n");
            SharedPreferences sharedPref = activity.getPreferences(Context.MODE_PRIVATE);
            String deviceAddress = sharedPref.getString("BtDeviceAddress", "");
            if (!deviceAddress.equals("")) {
                LogView.append("Connecting to Device '" + deviceAddress + "'\n");
                if (mConnectedThread != null) {
                    mConnectedThread.cancel();
                    mConnectedThread = null;
                }
                BluetoothDevice device = BA.getRemoteDevice(deviceAddress);
                BluetoothSocket socket = null;
                try {
                    socket = device.createRfcommSocketToServiceRecord(MY_UUID);
                    try {
                        // This is a blocking call and will only return on a successful connection or an exception
                        socket.connect();
                        mConnectedThread = new ConnectedThread(socket);
                        mConnectedThread.setPriority(Thread.MAX_PRIORITY);
                        mConnectedThread.start();
                    } catch (IOException e) {
                        LogView.append("ConnectedThread creation failed\n" + e.toString() + "\n");
                        mConnectedThread = null;
                    }
                } catch (IOException e) {
                    LogView.append("Socket create() failed\n" + e.toString() + "\n");
                    mConnectedThread = null;
                }
            }
            else
                LogView.append("no Device selected...\nPlease open Settings!");
        }
        else {
            LogView.append("Bluetooth not activated...\n");
            Intent turnOn = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(turnOn, 0);
        }
        ConnectButton.setEnabled(true);
    }

    private void setVolume()
    {
        if (mConnectedThread != null)
        {
            AudioVolume = Math.max(Math.min(AudioVolume, 9), -9);
            //LogView.append("Volume is set to " + AudioVolume + "\n");
            byte[] bytes = Charset.forName("UTF-8").encode(CharBuffer.wrap("V+" + AudioVolume)).array();
            if (AudioVolume < 0)
                bytes = Charset.forName("UTF-8").encode(CharBuffer.wrap("V" + AudioVolume)).array();
            mConnectedThread.write(bytes);
        }
    }

    private void setAdaptiveBitShift()
    {
        CheckBox checkbox = (CheckBox)findViewById(R.id.checkBox_adaptiveBitShift);
        Button button1 = (Button)findViewById(R.id.button_VolumeUp);
        Button button2 = (Button)findViewById(R.id.button_VolumeDown);
        button1.setEnabled(!checkbox.isChecked());
        button2.setEnabled(!checkbox.isChecked());
        if (mConnectedThread != null) {
            byte[] bytes = Charset.forName("UTF-8").encode(CharBuffer.wrap("B0")).array();
            if (checkbox.isChecked())
                bytes = Charset.forName("UTF-8").encode(CharBuffer.wrap("B1")).array();
            mConnectedThread.write(bytes);
        }
    }

    private void recordAudio()
    {
        Button button = (Button)findViewById(R.id.button_Record);
        if (mConnectedThread != null && isRecording == false)
        {
            CheckBox checkbox = (CheckBox)findViewById(R.id.checkBox_adaptiveBitShift);
            try {
                File sdCard = Environment.getExternalStorageDirectory();
                File dir = new File(sdCard.getAbsoluteFile() + "/IhaAudio");
                dir.mkdirs();
                dir.setReadable(true, false);
                dir.setWritable(true, false);
                dir.setExecutable(true, false);
                String currentDateandTime = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                String strExtension = ".a16";
                mConnectedThread.is32bitRecording = false;
                if (checkbox.isChecked() == true)
                {
                    strExtension = ".a32";
                    mConnectedThread.is32bitRecording = true;
                }
                FileOutputStream file = new FileOutputStream(dir + "/" + currentDateandTime + strExtension);
                mConnectedThread.OutputFile = new BufferedOutputStream(file);
                isRecording = true;
            } catch (Exception e) {
                LogView.append(e.getMessage());
            }
        }
        else
            isRecording = false;
        if (isRecording)
            button.setText("stop Recording");
        else
            button.setText("Record");


    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                LogView.append("Device found\n");
            }
            else if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                LogView.append("Device '" + device.getName() + "' is now connected\n");
                ConnectButton.setText("Reconnect");
            }
            else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                LogView.append("Done searching\n");
            }
            else if (BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED.equals(action)) {
                LogView.append("Device is about to disconnect\n");
            }
            else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                LogView.append("Device has disconnected\n");
                ConnectButton.setText("Connect");
                CheckBox checkbox = (CheckBox)findViewById(R.id.checkBox_adaptiveBitShift);
                checkbox.setChecked(false);
                setAdaptiveBitShift();
            }
        }
    };

    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final OutputStream mmOutStream;
        private BufferedInputStream bis = null;
        boolean run = true;
        public BufferedOutputStream OutputFile = null;
        public boolean is32bitRecording = false;

        public ConnectedThread(BluetoothSocket socket) {
            run = true;
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;
            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }
            mmOutStream = tmpOut;
            bis = new BufferedInputStream(tmpIn);
        }

        public void run() {
            int buffer_size = block_size * 4;
            int additionalBytesCount = 6;
            int count = 0, tmpByte;
            RingBuffer ringBuffer = new RingBuffer(buffer_size + additionalBytesCount);
            numBlocks = 0;
            lostBlocks = 0;

            int countCorrectPackages = 0;
            byte[] lastAudioBlock = new byte[buffer_size];
            while (run) {
                try {
                    ringBuffer.addByte((byte) bis.read());
                    count++;
                    if (ringBuffer.getByte(0) == (byte) 0x0 && ringBuffer.getByte(-1) == (byte) 0x80 && ringBuffer.getByte(-(buffer_size + 5)) == (byte) 0x7F && ringBuffer.getByte(-(buffer_size + 4)) == (byte) 0xFF) {
                        count = 0;
                        lastAudioBlock = Arrays.copyOf(ringBuffer.data(-(buffer_size + 3), buffer_size), buffer_size);
                        AudioVolume = (short) (((ringBuffer.getByte(-2) & 0xFF) << 8) | (ringBuffer.getByte(-3) & 0xFF));
                        countCorrectPackages++;
                    } else if (count == buffer_size + additionalBytesCount) {
                        count = 0;
                        lostBlocks++;
                        countCorrectPackages = 0;
                    }
                    if (count == 0) {
                        numBlocks++;
                        leftLevel = 0;
                        rightLevel = 0;
                        for (int countSample = 0; countSample < buffer_size; countSample += 2) {
                            short int16 = (short) (((lastAudioBlock[countSample + 1] & 0xFF) << 8) | (lastAudioBlock[countSample] & 0xFF));
                            if (countSample % 4 == 0)
                                leftLevel += Math.abs(int16);
                            else
                                rightLevel += Math.abs(int16);
                        }
                        if (OutputFile != null) {
                            for (int countSample = 0; countSample < buffer_size; countSample += 2)
                            {
                                short int16 = (short) (((lastAudioBlock[countSample + 1] & 0xFF) << 8) | (lastAudioBlock[countSample] & 0xFF));
                                if (is32bitRecording)
                                {
                                    int int32 = int16 << (16 - AudioVolume);
                                    OutputFile.write((byte)(int32 >> 24));
                                    OutputFile.write((byte)(int32 >> 16));
                                    OutputFile.write((byte)(int32 >> 8));
                                    OutputFile.write((byte)(int32));
                                }
                                else
                                {
                                    OutputFile.write((byte)(int16 >> 8));
                                    OutputFile.write((byte)(int16));
                                }
                            }
                            OutputFile.flush();
                            if (isRecording == false)
                            {
                                try {
                                    mConnectedThread.OutputFile.close();
                                } catch (Exception e) {}
                                mConnectedThread.OutputFile = null;
                            }
                        }
                        else{
                            audioTrack.write(lastAudioBlock, 0, buffer_size);
                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                textErrorValue.setText(String.format("%.3f", ((double) lostBlocks / (double) numBlocks) * 100.0));
                                textViewVolume.setText(String.format("%d", AudioVolume));
                                textErrorRealNumbersLabel.setText(String.format("%d", lostBlocks));
                                textViewLeftLevel.setText(String.format("%d", leftLevel / block_size));
                                textViewRightLevel.setText(String.format("%d", rightLevel / block_size));
                            }
                        });
                    }
                } catch (IOException e) {
                    this.cancel();
                    Log.d(TAG, e.toString());
                }
            }
            try {
                if (OutputFile != null)
                    OutputFile.close();
            } catch (Exception e) {
                Log.d(TAG, e.getMessage());
                this.cancel();
            }
        }

        /* Call this from the main activity to send data to the remote device */
        public void write(byte[] bytes) {
            try {
                mmOutStream.write(bytes);
            } catch (IOException e) { }
        }

        /* Call this from the main activity to shutdown the connection */
        public void cancel() {
             try {
                 run = false;
                 mmSocket.close();
            } catch (IOException e) { }
        }

        private class RingBuffer {
            private byte[] Data;
            private int idx;

            public RingBuffer(int BufferSize) {
                Data = new byte[BufferSize];
                idx = 0;
            }

            public void addByte(byte data) {
                idx = (idx + 1) % Data.length;
                Data[idx] = data;
            }

            public byte getByte(int currIdx)
            {
                currIdx = (idx + currIdx) % Data.length;
                if (currIdx < 0)
                    currIdx += Data.length;
                return Data[currIdx];
            }

            public byte[] data(int startIdx, int length) {
                byte[] returnArray = new byte[length];
                startIdx = (idx + startIdx) % Data.length;
                if (startIdx < 0)
                    startIdx += Data.length;
                int endIdx = startIdx + length;
                int tmpLen = Math.min(length, Data.length - startIdx);
                System.arraycopy(Data, startIdx, returnArray, 0, tmpLen);
                if (tmpLen != length)
                    System.arraycopy(Data, 0, returnArray, tmpLen, length - tmpLen);
                return returnArray;
            }
        };
    }

}
